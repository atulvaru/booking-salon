package com.app.dto;

//import com.app.entity.Role;
//
//import lombok.Data;
//
//@Data
//public class UserDto {
//	private Long id;
//	private String name;
//	private String email;
//	private Long roleId; // Assuming this field will be used for references
//}
