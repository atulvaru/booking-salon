package com.app.entity;

public enum BookingStatus {
	PENDING,
    CONFIRMED,
    COMPLETED,
    CANCELED
}
